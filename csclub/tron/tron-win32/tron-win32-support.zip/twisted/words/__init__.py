# -*- test-case-name: twisted.words.test -*-
# Copyright (c) Twisted Matrix Laboratories.
# See LICENSE for details.


"""Twisted Words: a Twisted Chat service.
"""

from twisted.words._version import version
__version__ = version.short()
