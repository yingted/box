#include<stdio.h>
const static int a[]={1,1,2,6,4},b[]={6,2,4,8};
int main(){
	for(;;){
		int n,zeroes=0,last=1;
		scanf("%i",&n);
		if(n<0)return 0;
		while(n>0){
			last=(last*a[n%5]*(n>4?b[(n/5)%4]:1))%10;
			zeroes+=n/=5;
		}
		printf("%iu%i\n",last,zeroes);
	}
}
